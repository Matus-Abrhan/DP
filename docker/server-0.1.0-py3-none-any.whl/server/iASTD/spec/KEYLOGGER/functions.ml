let alert1 () : unit =
  print_endline "T1053: Scheduled Task/Job: Scheduled Task\n"
  
let alert2 () : unit =
  print_endline "T1056: Input Capture: Keylogging\n"

let alert3 () : unit =
  print_endline "KEYLOGGER ALERT exit\n"
