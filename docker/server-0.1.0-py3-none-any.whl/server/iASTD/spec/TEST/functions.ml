let alert1 () : unit =
  print_endline "Alert: 1"

let alert2 () : unit =
  print_endline "Alert: 2"
