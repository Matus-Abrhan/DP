let alert1 () : unit =
  print_endline "T1486 ALERT exit\n"
