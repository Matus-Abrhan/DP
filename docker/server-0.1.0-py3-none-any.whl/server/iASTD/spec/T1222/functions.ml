let alert1 () : unit =
  print_endline "T1222 ALERT exit\n"
