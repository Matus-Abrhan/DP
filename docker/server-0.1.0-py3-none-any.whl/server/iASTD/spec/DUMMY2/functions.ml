let alert1 () : unit =
  print_endline "DUMMY2 ALERT\n"
