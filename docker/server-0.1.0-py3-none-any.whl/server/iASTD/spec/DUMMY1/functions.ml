let alert1 () : unit =
  print_endline "DUMMY1 ALERT\n"
