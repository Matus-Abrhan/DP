let action1 () : unit =
        print_endline "Alert: 1"

let action2 () : unit =
        print_endline "Alert: 2"

let action3 () : unit =
        print_endline "Alert: 3"
