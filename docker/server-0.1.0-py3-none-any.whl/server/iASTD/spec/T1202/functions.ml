let alert1 () : unit =
  print_endline "T1202 ALERT exit\n"
