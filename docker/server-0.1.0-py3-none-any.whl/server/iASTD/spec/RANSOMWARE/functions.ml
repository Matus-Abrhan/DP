let alert1 () : unit =
  print_endline "T1222: File and directory permissions modified\n"
  
let alert2 () : unit =
  print_endline "T1083: File and directory discovery\n"

let alert3 () : unit =
  print_endline "T1083: Data encryption for impact exit\n"
