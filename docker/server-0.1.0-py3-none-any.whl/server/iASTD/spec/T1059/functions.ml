let alert1 () : unit =
  print_endline "T1059 ALERT exit\n"
