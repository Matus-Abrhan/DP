from server.app import main


def run():
    main()


if __name__ == '__main__':
    run()
